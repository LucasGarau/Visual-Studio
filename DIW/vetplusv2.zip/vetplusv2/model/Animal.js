export function Animal(id, nom, sexe, numregistre, tipus) {
    this.id = id;
    this.nom = nom;
    this.sexe = sexe;
    this.numregistre = numregistre;
    this.tipus = tipus;
}