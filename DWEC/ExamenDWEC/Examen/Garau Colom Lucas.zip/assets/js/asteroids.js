class asteroid{
    nom;
    perillos;
    diametreMin;
    diametreMax;
    url;
}