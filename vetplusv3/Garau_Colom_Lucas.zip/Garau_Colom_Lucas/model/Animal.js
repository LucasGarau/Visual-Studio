export function Animal(idanimal, nom, sexe, numregistre, tipus) {
    this.idanimal = idanimal;
    this.nom = nom;
    this.sexe = sexe;
    this.numregistre=numregistre;
    this.tipus = tipus;
}